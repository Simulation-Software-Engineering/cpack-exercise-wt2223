#pragma once

void modifyAndPrintSets();

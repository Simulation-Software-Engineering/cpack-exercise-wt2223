#pragma once

void inspectDirectory();
